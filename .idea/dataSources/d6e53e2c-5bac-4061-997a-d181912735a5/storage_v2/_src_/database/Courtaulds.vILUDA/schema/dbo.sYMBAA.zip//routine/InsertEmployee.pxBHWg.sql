CREATE PROCEDURE InsertEmployee
       -- Add the parameters for the stored procedure here
       @password varchar(255),
       @first_name varchar(255),
       @last_name  varchar(255),
       @phone_number  varchar(255),
       @employee_address  varchar(255),
       @department_id int


AS
BEGIN

       INSERT INTO EmployeeSchema.Employee(password, first_name, last_name, phone_number, employee_address, department_id)

       VALUES
              (@password,@first_name,@last_name,@phone_number,@employee_address,@department_id)
END
go

